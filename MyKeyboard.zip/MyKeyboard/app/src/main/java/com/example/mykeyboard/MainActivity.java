package com.example.mykeyboard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(48, 96, 48, 48);
        l.setGravity(Gravity.TOP);

        TextView t = new TextView(this);
        t.setText("1. Включи клавиатуру\n2. Выбери её как текущую\n3. Проверь в поле ниже");
        t.setTextSize(18);
        l.addView(t);

        Button enable = new Button(this);
        enable.setText("1. Включить в настройках");
        enable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        l.addView(enable);

        Button pick = new Button(this);
        pick.setText("2. Выбрать клавиатуру");
        pick.setOnClickListener(v ->
                ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                        .showInputMethodPicker());
        l.addView(pick);

        EditText test = new EditText(this);
        test.setHint("Тут печатай");
        l.addView(test);

        setContentView(l);
    }
}
