package com.example.mykeyboard;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Клавиатура, нарисованная одним View.
 * Символ вводится сразу при касании (ACTION_DOWN), поддерживается мультитач,
 * поэтому быстрая печать не теряет нажатия.
 */
public class KeyboardView extends View {

    public interface Listener {
        void onText(String text);
        void onDelete();
        void onEnter();
        /** Заменить только что введённый символ (долгое нажатие: е -> ё). */
        void onReplaceLast(String text);
    }

    private enum Type { CHAR, SHIFT, DEL, LANG, SYM, ENTER, SPACE, SPACER }

    private static final int SHIFT_OFF = 0, SHIFT_ONCE = 1, SHIFT_CAPS = 2;

    private static final int COLOR_BG = 0xFF202124;
    private static final int COLOR_KEY = 0xFF3C4043;
    private static final int COLOR_KEY_SPECIAL = 0xFF2E3134;
    private static final int COLOR_KEY_ACTIVE = 0xFF4A4E52;
    private static final int COLOR_KEY_PRESSED = 0xFF6B7075;
    private static final int COLOR_ACCENT = 0xFF8AB4F8;
    private static final int COLOR_ACCENT_PRESSED = 0xFF669DF6;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_HINT = 0xFF9AA0A6;

    private static class Key {
        final Type type;
        final String label;   // базовый символ (строчный)
        final String alt;     // символ при долгом нажатии (или null)
        final float weight;
        float x, y, w, h;
        boolean pressed;

        Key(Type type, String label, String alt, float weight) {
            this.type = type;
            this.label = label;
            this.alt = alt;
            this.weight = weight;
        }
    }

    private class Press implements Runnable {
        final Key key;
        boolean longFired;
        boolean cancelled;
        boolean upper;

        Press(Key key) { this.key = key; }

        @Override
        public void run() {
            if (cancelled) return;
            if (key.type == Type.DEL) {
                if (listener != null) listener.onDelete();
                handler.postDelayed(this, 50);
            } else if (key.alt != null) {
                longFired = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                if (listener != null) listener.onReplaceLast(upper ? key.alt.toUpperCase() : key.alt);
                invalidate();
            }
        }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SparseArray<Press> pressed = new SparseArray<>();
    private final List<List<Key>> rows = new ArrayList<>();
    private final SharedPreferences prefs;

    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private Listener listener;
    private boolean russian;
    private boolean symbols = false;
    private int shift = SHIFT_OFF;
    private long lastShiftTap = 0;
    private float maxUnits = 10;

    public KeyboardView(Context context) {
        super(context);
        prefs = context.getSharedPreferences("mykeyboard", Context.MODE_PRIVATE);
        russian = prefs.getBoolean("ru", true);

        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setColor(COLOR_TEXT);
        iconPaint.setStyle(Paint.Style.STROKE);
        iconPaint.setStrokeWidth(dp(2));
        iconPaint.setStrokeCap(Paint.Cap.ROUND);
        iconPaint.setStrokeJoin(Paint.Join.ROUND);
        setBackgroundColor(COLOR_BG);
        buildKeys();
    }

    public void setListener(Listener l) { this.listener = l; }

    /** Автоматическая заглавная буква (начало предложения). */
    public void setAutoShift(boolean on) {
        if (shift == SHIFT_CAPS) return;
        int s = on ? SHIFT_ONCE : SHIFT_OFF;
        if (s != shift) { shift = s; invalidate(); }
    }

    public void setSymbols(boolean s) {
        if (symbols != s) {
            symbols = s;
            buildKeys();
            invalidate();
        }
    }

    // ---------------------------------------------------------------- раскладка

    private static String[] chars(String s) {
        String[] r = new String[s.length()];
        for (int i = 0; i < r.length; i++) r[i] = String.valueOf(s.charAt(i));
        return r;
    }

    private static String altFor(String c) {
        switch (c) {
            case "е": return "ё";
            case ",": return "!";
            case ".": return "?";
            default: return null;
        }
    }

    private Key ch(String c, float weight) {
        return new Key(Type.CHAR, c, altFor(c), weight);
    }

    private void buildKeys() {
        rows.clear();
        String[] a, b, c;
        if (symbols) {
            a = chars("@#$%&-+()/");
            b = chars("*\"':;!?=_");
            c = chars("<>[]{}~");
            maxUnits = 10;
        } else if (russian) {
            a = chars("йцукенгшщзхъ");
            b = chars("фывапролджэ");
            c = chars("ячсмитьбю");
            maxUnits = 12;
        } else {
            a = chars("qwertyuiop");
            b = chars("asdfghjkl");
            c = chars("zxcvbnm");
            maxUnits = 10;
        }

        List<Key> r0 = new ArrayList<>();
        for (String n : chars("1234567890")) r0.add(ch(n, maxUnits / 10f));
        rows.add(r0);

        List<Key> r1 = new ArrayList<>();
        for (String s : a) r1.add(ch(s, 1f));
        rows.add(r1);

        List<Key> r2 = new ArrayList<>();
        for (String s : b) r2.add(ch(s, 1f));
        rows.add(r2);

        List<Key> r3 = new ArrayList<>();
        r3.add(new Key(symbols ? Type.SPACER : Type.SHIFT, "", null, 1.5f));
        for (String s : c) r3.add(ch(s, 1f));
        r3.add(new Key(Type.DEL, "", null, 1.5f));
        rows.add(r3);

        List<Key> r4 = new ArrayList<>();
        r4.add(new Key(Type.SYM, symbols ? "ABC" : "?123", null, 1.5f));
        r4.add(new Key(Type.LANG, russian ? "RU" : "EN", null, 1.5f));
        r4.add(ch(",", 1f));
        r4.add(new Key(Type.SPACE, "", null, maxUnits - 6.5f));
        r4.add(ch(".", 1f));
        r4.add(new Key(Type.ENTER, "", null, 1.5f));
        rows.add(r4);

        layoutKeys();
    }

    private float rowHeight() { return dp(50); }
    private float padTop() { return dp(6); }
    private float padSide() { return dp(3); }

    private void layoutKeys() {
        int w = getWidth();
        if (w == 0) return;
        float unit = (w - 2 * padSide()) / maxUnits;
        float rh = rowHeight();
        for (int i = 0; i < rows.size(); i++) {
            List<Key> row = rows.get(i);
            float total = 0;
            for (Key k : row) total += k.weight;
            float x = padSide() + (maxUnits - total) * unit / 2f;
            float y = padTop() + i * rh;
            for (Key k : row) {
                k.x = x;
                k.y = y;
                k.w = k.weight * unit;
                k.h = rh;
                x += k.w;
            }
        }
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        int h = (int) (padTop() + rows.size() * rowHeight() + dp(6));
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        layoutKeys();
    }

    // ---------------------------------------------------------------- рисование

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(COLOR_BG);
        float gap = dp(3);
        float radius = dp(8);

        for (List<Key> row : rows) {
            for (Key k : row) {
                if (k.type == Type.SPACER) continue;
                rect.set(k.x + gap, k.y + gap, k.x + k.w - gap, k.y + k.h - gap);

                int color;
                if (k.type == Type.ENTER) {
                    color = k.pressed ? COLOR_ACCENT_PRESSED : COLOR_ACCENT;
                } else if (k.pressed) {
                    color = COLOR_KEY_PRESSED;
                } else if (k.type == Type.SHIFT && shift != SHIFT_OFF) {
                    color = COLOR_KEY_ACTIVE;
                } else if (k.type == Type.CHAR || k.type == Type.SPACE) {
                    color = COLOR_KEY;
                } else {
                    color = COLOR_KEY_SPECIAL;
                }
                fillPaint.setColor(color);
                canvas.drawRoundRect(rect, radius, radius, fillPaint);

                float cx = rect.centerX();
                float cy = rect.centerY();
                float s = dp(8);

                switch (k.type) {
                    case CHAR: {
                        String text = shift != SHIFT_OFF ? k.label.toUpperCase() : k.label;
                        textPaint.setTypeface(Typeface.DEFAULT);
                        textPaint.setColor(COLOR_TEXT);
                        textPaint.setTextSize(sp(k.label.matches("[0-9]") ? 20 : 22));
                        drawCenteredText(canvas, text, cx, cy);
                        if (k.alt != null) {
                            textPaint.setTextSize(sp(10));
                            textPaint.setColor(COLOR_HINT);
                            canvas.drawText(k.alt, rect.right - dp(8), rect.top + dp(13), textPaint);
                        }
                        break;
                    }
                    case LANG:
                    case SYM:
                        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
                        textPaint.setColor(COLOR_TEXT);
                        textPaint.setTextSize(sp(15));
                        drawCenteredText(canvas, k.label, cx, cy);
                        break;
                    case SPACE:
                        textPaint.setTypeface(Typeface.DEFAULT);
                        textPaint.setColor(COLOR_HINT);
                        textPaint.setTextSize(sp(13));
                        drawCenteredText(canvas, russian ? "Русский" : "English", cx, cy);
                        break;
                    case SHIFT:
                        drawShiftIcon(canvas, cx, cy - dp(1), s);
                        break;
                    case DEL:
                        iconPaint.setColor(COLOR_TEXT);
                        drawDeleteIcon(canvas, cx, cy, s);
                        break;
                    case ENTER:
                        iconPaint.setColor(0xFF202124);
                        drawEnterIcon(canvas, cx, cy, s);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    private void drawCenteredText(Canvas c, String text, float cx, float cy) {
        float y = cy - (textPaint.ascent() + textPaint.descent()) / 2f;
        c.drawText(text, cx, y, textPaint);
    }

    private void drawShiftIcon(Canvas c, float cx, float cy, float s) {
        Path p = new Path();
        p.moveTo(cx, cy - s);
        p.lineTo(cx + s, cy);
        p.lineTo(cx + s * 0.5f, cy);
        p.lineTo(cx + s * 0.5f, cy + s);
        p.lineTo(cx - s * 0.5f, cy + s);
        p.lineTo(cx - s * 0.5f, cy);
        p.lineTo(cx - s, cy);
        p.close();
        iconPaint.setColor(COLOR_TEXT);
        iconPaint.setStyle(shift == SHIFT_OFF ? Paint.Style.STROKE : Paint.Style.FILL_AND_STROKE);
        c.drawPath(p, iconPaint);
        if (shift == SHIFT_CAPS) {
            float by = cy + s + dp(4);
            c.drawLine(cx - s * 0.5f, by, cx + s * 0.5f, by, iconPaint);
        }
        iconPaint.setStyle(Paint.Style.STROKE);
    }

    private void drawDeleteIcon(Canvas c, float cx, float cy, float s) {
        Path p = new Path();
        p.moveTo(cx - s * 1.3f, cy);
        p.lineTo(cx - s * 0.5f, cy - s * 0.9f);
        p.lineTo(cx + s * 1.3f, cy - s * 0.9f);
        p.lineTo(cx + s * 1.3f, cy + s * 0.9f);
        p.lineTo(cx - s * 0.5f, cy + s * 0.9f);
        p.close();
        c.drawPath(p, iconPaint);
        float ex = cx + s * 0.4f, d = s * 0.4f;
        c.drawLine(ex - d, cy - d, ex + d, cy + d, iconPaint);
        c.drawLine(ex - d, cy + d, ex + d, cy - d, iconPaint);
    }

    private void drawEnterIcon(Canvas c, float cx, float cy, float s) {
        Path p = new Path();
        p.moveTo(cx + s, cy - s * 0.8f);
        p.lineTo(cx + s, cy + s * 0.2f);
        p.lineTo(cx - s, cy + s * 0.2f);
        c.drawPath(p, iconPaint);
        c.drawLine(cx - s, cy + s * 0.2f, cx - s + s * 0.6f, cy + s * 0.2f - s * 0.6f, iconPaint);
        c.drawLine(cx - s, cy + s * 0.2f, cx - s + s * 0.6f, cy + s * 0.2f + s * 0.6f, iconPaint);
    }

    // ---------------------------------------------------------------- касания

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int idx = e.getActionIndex();
                Key k = keyAt(e.getX(idx), e.getY(idx));
                if (k != null) press(e.getPointerId(idx), k);
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                for (int i = 0; i < e.getPointerCount(); i++) {
                    Press p = pressed.get(e.getPointerId(i));
                    if (p == null || p.cancelled) continue;
                    Key k = p.key;
                    float x = e.getX(i), y = e.getY(i);
                    float slop = dp(12);
                    boolean outside = x < k.x - slop || x > k.x + k.w + slop
                            || y < k.y - slop || y > k.y + k.h + slop;
                    if (outside) {
                        p.cancelled = true;
                        handler.removeCallbacks(p);
                        k.pressed = false;
                        invalidate();
                    }
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                release(e.getPointerId(e.getActionIndex()));
                break;
            case MotionEvent.ACTION_CANCEL:
                releaseAll();
                break;
        }
        return true;
    }

    private Key keyAt(float x, float y) {
        if (rows.isEmpty()) return null;
        int r = (int) ((y - padTop()) / rowHeight());
        r = Math.max(0, Math.min(rows.size() - 1, r));
        Key best = null;
        float bestDist = Float.MAX_VALUE;
        for (Key k : rows.get(r)) {
            if (k.type == Type.SPACER) continue;
            if (x >= k.x && x < k.x + k.w) return k;
            float d = Math.abs(x - (k.x + k.w / 2f));
            if (d < bestDist) { bestDist = d; best = k; }
        }
        return best;
    }

    private void press(int id, Key k) {
        Press p = new Press(k);
        pressed.put(id, p);
        k.pressed = true;
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);

        switch (k.type) {
            case CHAR:
                p.upper = shift != SHIFT_OFF;
                typeChar(k.label); // вводим сразу, чтобы порядок букв не путался
                if (k.alt != null) handler.postDelayed(p, 450);
                break;
            case SPACE:
                typeRaw(" ");
                break;
            case DEL:
                if (listener != null) listener.onDelete();
                handler.postDelayed(p, 400);
                break;
            case ENTER:
                if (listener != null) listener.onEnter();
                break;
            case SHIFT:
                toggleShift();
                break;
            case LANG:
                russian = !russian;
                symbols = false;
                prefs.edit().putBoolean("ru", russian).apply();
                buildKeys();
                break;
            case SYM:
                symbols = !symbols;
                buildKeys();
                break;
            default:
                break;
        }
        invalidate();
    }

    private void release(int id) {
        Press p = pressed.get(id);
        if (p == null) return;
        pressed.remove(id);
        handler.removeCallbacks(p);
        p.key.pressed = false;
        invalidate();
    }

    private void releaseAll() {
        for (int i = pressed.size() - 1; i >= 0; i--) {
            Press p = pressed.valueAt(i);
            handler.removeCallbacks(p);
            p.key.pressed = false;
        }
        pressed.clear();
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        releaseAll();
        super.onDetachedFromWindow();
    }

    private void toggleShift() {
        long now = SystemClock.uptimeMillis();
        if (shift == SHIFT_ONCE && now - lastShiftTap < 350) shift = SHIFT_CAPS;
        else if (shift == SHIFT_OFF) shift = SHIFT_ONCE;
        else shift = SHIFT_OFF;
        lastShiftTap = now;
    }

    private void typeChar(String lower) {
        typeRaw(shift != SHIFT_OFF ? lower.toUpperCase() : lower);
    }

    private void typeRaw(String s) {
        if (shift == SHIFT_ONCE) shift = SHIFT_OFF; // сбросить до отправки: сервис может снова включить авто-Shift
        if (listener != null) listener.onText(s);
    }

    private float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, getResources().getDisplayMetrics());
    }
}
