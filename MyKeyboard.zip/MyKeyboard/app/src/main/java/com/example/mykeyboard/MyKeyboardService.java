package com.example.mykeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;

public class MyKeyboardService extends InputMethodService {

    private static final String[][] EN = {
            {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"},
            {"a", "s", "d", "f", "g", "h", "j", "k", "l"},
            {"z", "x", "c", "v", "b", "n", "m"}
    };
    private static final String[][] RU = {
            {"й", "ц", "у", "к", "е", "н", "г", "ш", "щ", "з", "х"},
            {"ф", "ы", "в", "а", "п", "р", "о", "л", "д", "ж", "э"},
            {"я", "ч", "с", "м", "и", "т", "ь", "б", "ю"}
    };

    private LinearLayout root;
    private boolean shift = false;
    private boolean russian = false;

    @Override
    public View onCreateInputView() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF202124);
        root.setPadding(4, 8, 4, 8);
        rebuild();
        return root;
    }

    private void rebuild() {
        root.removeAllViews();
        String[][] layout = russian ? RU : EN;

        for (String[] letters : layout) {
            LinearLayout row = newRow();
            for (String ch : letters) {
                String shown = shift ? ch.toUpperCase() : ch;
                row.addView(key(shown, 1f, v -> typeText(shown)));
            }
            root.addView(row);
        }

        LinearLayout bottom = newRow();
        bottom.addView(key(shift ? "⬆" : "⇧", 1.3f, v -> { shift = !shift; rebuild(); }));
        bottom.addView(key(russian ? "RU" : "EN", 1.3f, v -> { russian = !russian; rebuild(); }));
        bottom.addView(key(",", 1f, v -> typeText(",")));
        bottom.addView(key(" ", 4f, v -> typeText(" ")));
        bottom.addView(key(".", 1f, v -> typeText(".")));
        bottom.addView(key("⌫", 1.3f, v -> sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)));
        bottom.addView(key("⏎", 1.3f, v -> pressEnter()));
        root.addView(bottom);
    }

    private LinearLayout newRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 140));
        return row;
    }

    private Button key(String label, float weight, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(18);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(0xFF3C4043);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(0, 0, 0, 0);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, weight);
        p.setMargins(3, 3, 3, 3);
        b.setLayoutParams(p);
        b.setOnClickListener(l);
        return b;
    }

    private void typeText(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(s, 1);
        if (shift) { shift = false; rebuild(); }
    }

    private void pressEnter() {
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ei != null) {
            int action = ei.imeOptions & EditorInfo.IME_MASK_ACTION;
            boolean noAction = (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
            if (!noAction && action != EditorInfo.IME_ACTION_NONE
                    && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.performEditorAction(action);
                return;
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }
}
