package com.example.mykeyboard;

import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

public class MyKeyboardService extends InputMethodService implements KeyboardView.Listener {

    private KeyboardView view;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable autoShiftTask = this::updateAutoShift;

    @Override
    public View onCreateInputView() {
        view = new KeyboardView(this);
        view.setListener(this);
        return view;
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false; // в горизонтальном режиме не растягивать поле ввода на весь экран
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        if (view == null) return;
        int cls = info.inputType & InputType.TYPE_MASK_CLASS;
        view.setSymbols(cls == InputType.TYPE_CLASS_NUMBER
                || cls == InputType.TYPE_CLASS_PHONE
                || cls == InputType.TYPE_CLASS_DATETIME);
        updateAutoShift();
    }

    @Override
    public void onText(String text) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.commitText(text, 1);

        // Запрос к полю ввода медленный, поэтому после обычной буквы его не делаем.
        EditorInfo ei = getCurrentInputEditorInfo();
        boolean wordLike = text.length() == 1 && Character.isLetterOrDigit(text.charAt(0));
        boolean capsAlways = ei != null && (ei.inputType & (InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                | InputType.TYPE_TEXT_FLAG_CAP_WORDS)) != 0;
        if (wordLike && !capsAlways) {
            if (view != null) view.setAutoShift(false);
        } else {
            updateAutoShift();
        }
    }

    @Override
    public void onReplaceLast(String text) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.beginBatchEdit();
        ic.deleteSurroundingText(1, 0);
        ic.commitText(text, 1);
        ic.endBatchEdit();
    }

    @Override
    public void onDelete() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        // при удержании ⌫ не заваливаем поле ввода запросами
        handler.removeCallbacks(autoShiftTask);
        handler.postDelayed(autoShiftTask, 120);
    }

    @Override
    public void onEnter() {
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ei != null) {
            int action = ei.imeOptions & EditorInfo.IME_MASK_ACTION;
            boolean noAction = (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
            if (!noAction && action != EditorInfo.IME_ACTION_NONE
                    && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) ic.performEditorAction(action);
                return;
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        updateAutoShift();
    }

    /** Заглавная буква в начале предложения, если поле ввода этого просит. */
    private void updateAutoShift() {
        if (view == null) return;
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ic == null || ei == null
                || (ei.inputType & InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) {
            view.setAutoShift(false);
            return;
        }
        view.setAutoShift(ic.getCursorCapsMode(ei.inputType) != 0);
    }
}
